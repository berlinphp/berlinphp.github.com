<?xml version="1.0" encoding="iso-8859-1"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Admin Login</title>
  <meta name="GENERATOR" content="Quanta Plus" />
  <style type="text/css" media="screen, projection">
  @import "style.css";
  </style>

</head>
<body>
<div id="header">MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM</div>
<div id="contentContainer">
  <div id="menu1" class="menu">Men� 1</div>
  <div id="menu2" class="menu">Men� 2</div>
  <div>Hallo das ist jetzt der Content von unsere Seite. Dies ist leider nur ein kleiner Blindetext, der keine sinnvolle Bedeutung hat. Ich hoffe, dass er lang genug ist, damit man was auf der Seite sieht.</div>
</div>
</body>
</html>
 
