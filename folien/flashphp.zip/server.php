<?php
require_once 'Net/Server/Handler.php';
require_once 'Net/Server.php';
class Flash_Server_Handle extends Net_Server_Handler {

    /**
    * If the user sends data, send it back to him
    *
    * @access   public
    * @param    integer $clientId
    * @param    string  $data
    */
    function onReceiveData( $clientId = 0, $data = "" ) {
		$this->_server->broadcastData($data."\0");
    }
    
    function onConnect($clientId = 0) {
    	$this->_server->sendData($clientId, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
		."<message text=\"Hallo\"></message>\0");
    }
}

    // create a server that forks new processes
	$server	 = &Net_Server::create('sequential', 'localhost', 9090);

    $handler = &new Flash_Server_Handle;

    // hand over the object that handles server events
    $server->setCallbackObject($handler);

    // start the server
    $server->start();
?>
