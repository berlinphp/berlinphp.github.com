<?php
  Ming_useSWFVersion(5);

  $s = new SWFShape();
  $s->setRightFill($s->addFill(0xFF, 0x00, 0x00));
  $s->movePenTo(-25, -25);
  $s->drawLine(50, 0);
  $s->drawLine(0, 50);
  $s->drawLine(-50, 0);
  $s->drawLine(0, -50);

  $b = new SWFButton();
  $b->addShape($s, SWFBUTTON_HIT | SWFBUTTON_UP | SWFBUTTON_DOWN | SWFBUTTON_OVER);

  $b->addAction(new SWFAction("startDrag('/test', 0);"),
SWFBUTTON_MOUSEDOWN);

  $b->addAction(new SWFAction("stopDrag();"),
SWFBUTTON_MOUSEUP | SWFBUTTON_MOUSEUPOUTSIDE);

  $p = new SWFSprite();
  $p->add($b);
  $p->nextFrame();

  $m = new SWFMovie();
  $m->setDimension(320, 240);

  $i = $m->add($p);
  $i->setName('test');
  $i->moveTo(160,120);

  header('Content-type: application/x-shockwave-flash');
  $m->output();
?>
