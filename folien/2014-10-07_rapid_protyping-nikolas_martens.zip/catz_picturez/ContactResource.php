<?php
use watoki\curir\Resource;
use watoki\curir\responder\Redirecter;

class ContactResource extends Resource {

    /**
     * @param bool $success
     * @return array
     */
    public function doGet($success = false) {
        return [
            'success' => $success
        ];
    }

    public function doPost($name, $email, $phone, $message) {
        mail('me@example.com', 'Contact', "New message from $name ($phone): $message", "From: $name <$email>");
        return $this->doGet(true);
    }

} 