This is a demo web application with the purpose to showcase 
part of watoki: curir, tempan and boxes.

If you would like to find out what's behind this and why I did it,
drop me a line: http://rtens.org