<?php
use watoki\curir\Resource;

class GalleryResource extends Resource {

    public function doGet()
    {
        return [
            'cat' => $this->readCats()
        ];
    }

    /**
     * @param $file
     * @return array
     */
    private function cat($file)
    {
        return [
            'link' => ['href' => 'picz/' . $file],
            'image' => ['src' => 'picz/' . $file]
        ];
    }

    /**
     * @return array
     */
    private function readCats()
    {
        $cats = [];
        foreach (glob(__DIR__ . '/picz/*') as $file) {
            $cats[] = $this->cat(basename($file));
        }
        return $cats;
    }

}