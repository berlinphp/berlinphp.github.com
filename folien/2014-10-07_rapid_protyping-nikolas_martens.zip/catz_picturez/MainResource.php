<?php
use watoki\boxes\BoxContainer;

class MainResource extends BoxContainer {

    public function doGet() {
        return $this->getBoxes();
    }

    protected function registerBoxes() {
        $this->addBox('gallery');
        $this->addBox('contact');
    }
}