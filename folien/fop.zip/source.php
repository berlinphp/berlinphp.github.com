<?php
highlight_file("fop.php");
?>
