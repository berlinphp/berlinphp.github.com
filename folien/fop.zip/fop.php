<?php
// Ben�tigte Datein Includen
require_once "XML/sql2xml.php";
require_once "XML/fo2pdf.php";

// Verbindung zur MySQL DB aufbauen, jede andere ist auch m�glich
$sql2xmlclass = new xml_sql2xml("mysql://schulung:password@localhost/schulung");

// Tag im XML Dokument umbennen
$sql2xmlclass->setOptions(array(
                             'tagNameResult' => 'rechnung'
						  ));
						  
// Abfrage absetzen und daraus XML generieren
// Left Join sorgt daf�r, dass es richtig dargestellt wird
$xmlstring = $sql2xmlclass->getxml("select * from kunden left join positionen ".
				" on kunden.id = positionen.kunde WHERE kunde = 3");
				
// XML Datei speichern
$fp = fopen("rechnung.xml", "w");
fputs($fp, $xmlstring);
fclose($fp);


// PDF mit FOP generieren (relativ langsam)
exec('fop -xsl rechnung.xsl -xml rechnung.xml -pdf rechnung.pdf', $output);

// Richtigen Header senden
Header("Content-type: application/pdf\r\nContent-Length: ".filesize("rechnung.pdf"));

// Rechnung ausgeben
readfile("rechnung.pdf");

// Demo wie es mit xml_fo2pdf aussehen k�nnte
/*
$fop = new xml_fo2pdf();
$fop->setRenderer("pdf");
$fop->setContentType("application/pdf");
$fop->setConfigFile("userconfig.xml");
if (PEAR::isError($error = $fop->run("rechnung.fo"))) {
  die("FOP ERROR: ". $error->getMessage());
}
$fop->printPDF();
$fop->deletePDF();
*/
?>
