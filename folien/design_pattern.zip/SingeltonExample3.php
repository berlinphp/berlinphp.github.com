<?php 
class Singleton { 
   /** 
   * The singleton instance is stored here 
   */ 
   static private $instance = false; 

   /** 
   * Make the constructor private to prevent the class being 
   * instantiated directly 
   */ 
   private function __construct() {} 

   /** 
   * Use this static method to get a singleton instance 
   */ 
   static function instance() { 
       if(!Singleton::$instance) { 
           Singleton::$instance = new Singleton(); 
       } 
       return Singleton::$instance; 
   } 
} 


$single = Singleton::instance();
?>