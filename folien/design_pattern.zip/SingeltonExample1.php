<?php
/**
*
* @author Manuel Blechschmidt<mb@notjusthosting.com>
* @version 0.1
* @package Pattern
*/

class Pattern_SingeltonExample1 {

    function &singelton() {
        static $object;
        if(!isset($object)) {
            $object =& new Pattern_SingeltonExample1();
        }
        return $object;
    }

}

$singelton = Pattern_SingeltonExample1::singelton();

?>