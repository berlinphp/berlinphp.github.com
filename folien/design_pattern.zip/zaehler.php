<?php
function &zaehler() {
    static $zahl = 0;
    $zahl++;
    return $zahl;
}

echo zaehler();
echo zaehler();
?>