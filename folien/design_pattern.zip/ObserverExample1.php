<?php
/**
*
* @author Manuel Blechschmidt<mb@notjusthosting.com>
* @version 0.1
* @package Pattern
*/

class ObservableObject1 {

    /**
    * Listeners which receive Events
    */
    var $_listener = array();
    
    /**
    * A property of the Object
    */
    var $property = "Hallo";

    /**
    * Function to add Listener to the observable object
    * The parameter must be an ObserverListener
    * @param object $listener
    * @return void
    */
    function addListener(&$listener) {
        if(is_a($listener, "ObserverListener")) {
            $this->_listener[] =& $listener;
        } else {
            trigger_error("Object has wrong type should"
            ." be ObserverListener but is ".get_class($listener));
        }
    }
    
    /**
    * Function which fire an eventString to every Listener
    * @param String $eventStrin
    */
    function fireEvent($eventString) {
        foreach($this->_listener as $key) { $key->eventTriggerd($eventString); }
    }
    
    /**
    * Getter for the Property
    */
    function setProperty($property) {
        $oldproperty = $this->property;
        $this->property = $property;
        $this->fireEvent("PropertyChangeEvent: Property Name \$property".
        " has changed from $oldproperty to $property");
    }
    
    /**
    * Setter for the Property
    */
    function getProperty() {
        return $this->property;
    }
}

/**
* ObserverListener- class that can receiv Events form an observable Object
*
*/
class ObserverListener {

    /**
    * Function which is triggerd when an Event happend in the
    * observed object.
    * A message about the state of the observable Object is in the String
    * Try to don't call this method directly
    * @param String 
    */
    function eventTriggerd($eventString){
        echo $eventString;
    }
}

$observableobject = new ObservableObject1();
$listener = new ObserverListener();
$observableobject->addListener($listener);

$observableobject->setProperty("Welt");

?>
