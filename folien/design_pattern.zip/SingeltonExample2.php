<?php
/**
*
* @author Manuel Blechschmidt<mb@notjusthosting.com>
* @version 0.1
* @package Pattern
*/

class Pattern_SingeltonExample2 {

    var $static;

    function Pattern_SingeltonExample2() {
        $this->static =& $GLOBALS["SingeltonExample2"];
    }

    function &singelton() {
        if(!isset($static)) {
            $static =& new Pattern_SingeltonExample2();
        }
        return $static;
    }

}

$singelton = Pattern_SingeltonExample2::singelton();

?>