<?php
/**
*
* @author Manuel Blechschmidt<mb@notjusthosting.com>
* @version 0.1
* @package Pattern
*/

class ObservableObject2 {

    /**
    *Listener which receice the PropertyChangeEvents
    */
    var $_listener = array();
    
    var $_property = "Hallo";

    /**
    * Function to add Listener to the observable object
    * The parameter must be an ObserverListener
    * @param object $listener
    * @return void
    */
    function addPropertyChangeListener(&$listener) {
        if(is_a($listener, "PropertyChangeListener")) {
            $this->_listener[] = & $listener;
        } else {
            trigger_error("Object has wrong type should"
            ." be PropertChangeListener but is ".get_class($listener));
        }
    }
    
    /**
    * Function which fire an eventString to every Listener
    * @param Object $propertChangeEvent
    */
    function firePropertyChangeEvent($propertChangeEvent) {
        foreach($this->_listener as $key) { $key->eventTriggerd($propertChangeEvent); }
    }
    
    /**
    * Getter for the Property
    */
    function setProperty($property) {
        $oldproperty = $this->_property;
        $this->_property = $property;
        $this->firePropertyChangeEvent(new PropertyChangeEvent("Property",
					$oldproperty, $property));
    }
    
    /**
    * Setter for the Property
    */
    function getProperty() {
        return $this->_property;
    }
}

/**
* ObserverListener- class that can receiv Events form an observable Object
*
*/
class PropertyChangeListener {

    /**
    * Function which is triggerd when an Event happend in the
    * observed object.
    * A object which encapsulates the changes of the observable Object is in the
    * parameter.
    * Try to don't call this method directly
    * @param object $propertyChangeEvent
    */
    function eventTriggerd($propertyChangeEvent){
        var_dump($propertyChangeEvent);
        echo "Property Changed(Name: ".$propertyChangeEvent->getPropertyName()
        ." oldValue: ".$propertyChangeEvent->getPropertyOldValue()
        ." newValue: ".$propertyChangeEvent->getPropertyNewValue().")";
    }
}


/**
* Class which encapsulated an PropertyChangeEvent.
*
*/
class PropertyChangeEvent {

    var $propertyName;
    var $propertyNewValue;
    var $propertyOldValue;
    
    function PropertyChangeEvent($propertyName, $propertyOldValue, $propertyNewValue) {
        $this->propertyName = $propertyName;
        $this->propertyOldValue = $propertyOldValue;
        $this->propertyNewValue = $propertyNewValue;
    }
    
    function getPropertyOldValue() {
        return $this->propertyOldValue;
    }
    
    function getPropertyName() {
        return $this->propertyName;
    }
    
    function getPropertyNewValue() {
        return $this->propertyNewValue;
    }
}

$observableobject = new ObservableObject2();
$listener = new PropertyChangeListener();
$observableobject->addPropertyChangeListener($listener);

$observableobject->setProperty("Welt");


?>
