<?php
if (stristr($_SERVER["HTTP_ACCEPT"],"application/xhtml+xml")) {
    header("Content-type: application/xhtml+xml");
} else {
    header("Content-type: text/html");
}
error_reporting(E_STRICT);
// If you open and close <?php often it becomes slow
include_once("User.php");
// Controller
$error = "";
if(!empty($_GET["delete"]) && $_GET["delete"] === "all") {
    User::deleteAllUsers();
}
if(!empty($_POST["ok"]) && !empty($_POST["login"]) && !empty($_POST["password"]) && !empty($_POST["vorname"]) && !empty($_POST["nachname"]) && !empty($_POST["email"] ) && User::validateEmail($_POST["email"])) {
    // Model
    User::addUser($_POST["login"], $_POST["password"], $_POST["vorname"], $_POST["nachname"], $_POST["email"]);
} elseif(!empty($_POST["ok"]) && (empty($_POST["login"]) || empty($_POST["password"]) || empty($_POST["vorname"]) || empty($_POST["nachname"]) || empty($_POST["email"]))) {
    $error = "<p>Bitte f�llen Sie alle Felder aus.</p>";
} elseif(!empty($_POST["ok"]) && !User::validateEmail($_POST["email"])) {
    $error = "<p>Bitte geben Sie eine valide Emailadresse ein.</p>";
}   
// View
?>
<?php if(!stristr($_SERVER["HTTP_USER_AGENT"], "MSIE 6.0")) { echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?".">\n"; } ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="de">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="author" content="Manuel Blechschmidt" />
<title>WebInterface zum Testen</title>
<style type="text/css">
@import "style.css";
</style>
</head>
<body>
<h1 id="ordaHead">Manuels tolles Testinterface</h1>
<table id="userTable" summary="Die Benutzerdaten aller Benutzer.">
<tr>
    <th>id</th>
    <th>Login</th>
    <th>Passwort</th>
    <th>Vorname</th>
    <th>Nachname</th>
    <th>Email</th>
</tr>
<?php
// Controller
$array = User::loadAllUsers();
// View
foreach($array as $row) {
    echo "<tr>";
    foreach($row as $cell) {
        echo "<td>$cell</td>";
    }
    echo "</tr>";
}
?>
</table>
<p><a href="?delete=all">Alle l�schen</a></p>
<?php echo $error; ?>
<form id="createNewUser" action="index.php" method="post">
<fieldset>
    <legend>F�ge neuen User hinzu</legend>
    <label class="left" for="login">Login</label> <input type="text" name="login" id="login" class="right" title="Bitte geben Sie einen Login ein. M�glichst aus Kleinbuchstaben." /><br />
    <label class="left" for="password">Password</label> <input type="password" name="password" id="password" class="right" title="Geben Sie ein zuf�lliges Passwort ein." /><br />
    <label class="left" for="vorname">Vorname</label> <input type="text" name="vorname" id="vorname" class="right" title="Der Vorname des Benutzers. Schreiben Sie den ersten Buchstaben gro�." /><br />
    <label class="left" for="nachname">Nachname</label> <input type="text" name="nachname" id="nachname" class="right" title="Der Nachname des Benutzers. Es sind auch Doppelnamen m�glich." /><br />
    <label class="left" for="email">Email</label> <input type="text" name="email" id="email" class="right" title="Die Emailadresse des Benutzers. Sie k�nnen nur eine angeben." /><br />
    <input type="submit" name="ok" value="ok" id="ok"/>
  </fieldset>
</form>
<div id="copyright">&copy; 2005 Manuel Blechschmidt some right reserved</div>
<p>
    <a href="http://validator.w3.org/check?uri=referer"><img
        src="img/valid-xhtml10"
        alt="Valid XHTML 1.0!" height="31" width="88" /></a>
    <a href="http://jigsaw.w3.org/css-validator/check/referer">
         <img style="border:0;width:88px;height:31px"
             src="img/vcss" 
             alt="Valid CSS!" />
    </a>

    <!-- Creative Commons License -->
    <a rel="license" href="http://creativecommons.org/licenses/by/2.0/de/"><img alt="Creative Commons License" border="0" src="img/somerights20.gif" /></a><br />
    This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/2.0/de/">Creative Commons Attribution 2.0 Germany License</a>.
    <!-- /Creative Commons License -->
    
    
    <!--
    
    <rdf:RDF xmlns="http://web.resource.org/cc/"
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
    <Work rdf:about="">
    <dc:type rdf:resource="http://purl.org/dc/dcmitype/Interactive" />
    <license rdf:resource="http://creativecommons.org/licenses/by/2.0/de/" />
    </Work>
    
    <License rdf:about="http://creativecommons.org/licenses/by/2.0/de/">
    <permits rdf:resource="http://web.resource.org/cc/Reproduction" />
    <permits rdf:resource="http://web.resource.org/cc/Distribution" />
    <requires rdf:resource="http://web.resource.org/cc/Notice" />
    <requires rdf:resource="http://web.resource.org/cc/Attribution" />
    <permits rdf:resource="http://web.resource.org/cc/DerivativeWorks" />
    </License>
    
    </rdf:RDF>
    
    -->

</p>
</body>
</html>
