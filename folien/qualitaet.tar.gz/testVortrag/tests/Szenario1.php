<?php
require_once 'PHPUnit2/Framework/TestCase.php';
require_once 'User.php';
class Szenario1 extends PHPUnit2_Framework_TestCase {

    private $userId;

    public function __construct($name) {
        // Do nothing just pass it through, we also could delete the consturctor completely
        parent::__construct($name);
    }

    /**
    * Do some initialization for the test, like making a database connection,
    * put data into some files etc.
    */
    public function setUp() {
        file_put_contents("users.txt", "1|manuelb|geheim|Manuel|Blechschmidt|Manuel.Blechschmidt@gmx.de\n");
        $this->setLooselyTyped(false);
        $this->userId = 1;
    }
 
    /**
    * Tests if load user without problems
    */
    public function testLoadUser() {
        $user = User::loadUser($this->userId);
        self::assertEquals($user->id, 1);
        self::assertEquals($user->login, "manuelb");
        self::assertEquals($user->password, "geheim");
        self::assertEquals($user->firstname, "Manuel");
        self::assertEquals($user->lastname, "Blechschmidt");
        self::assertEquals($user->email, "Manuel.Blechschmidt@gmx.de");
    }

    /**
    * The functions should also work if the file does not exists
    */
    function testFileNotExists() {
        unlink("users.txt");
	User::loadAllUsers();
	try {
	    User::loadUser(1);
	    self::fail();
	} catch(Exception $ex) {
	    User::addUser("hans", "secret", "Hans", "Peter", "hans_peter@web.de");
	}
    }

    /**
    * Test if an exception is thrown, if the user isn't found
    */
    public function testLoadUserNotFound() {
        try {
            User::loadUser(2);
            self::fail();
        } catch(Exception $ex) {
        }
    }

    /**
    * Tests if the class loads all uses
    */
    public function testLoadAllUsers() {
        $array = User::loadAllUsers();
        self::assertEquals($array, array(array(1, "manuelb", "geheim", "Manuel", "Blechschmidt", "Manuel.Blechschmidt@gmx.de")));
    }

    /**
    * Test if you can add a user and get back the right id which is incremented
    */
    public function testAddUser() {
        $this->userId = User::addUser("hans", "secret", "Hans", "Peter", "hans_peter@web.de");
        self::assertEquals($this->userId, 2);
        $user = User::loadUser($this->userId);
        self::assertEquals($user->id, 2);
        self::assertEquals($user->login, "hans");
        self::assertEquals($user->password, "secret");
        self::assertEquals($user->firstname, "Hans");
        self::assertEquals($user->lastname, "Peter");
        self::assertEquals($user->email, "hans_peter@web.de");
    }

    /**
    * Tests if delete all Users deletes all Users
    */
    function testDeleteAllUsers() {
        User::deleteAllUsers();
	self::assertEquals(User::loadAllUsers(), array());
    }

    /**
    * Test if you can an positiv answer on a positv email
    */
    public function testValidatePositivEmail() {
        self::assertTrue(User::validateEmail("manuel.blechschmidt@gmx.de"));
        self::assertTrue(User::validateEmail("blechschmidt@test.gmx.de"));
        // Theoreticly we could also do something like test@212.215.34.67
        // but this is to wierd
    }

    /**
    * Test if you get an exception with an negative Email
    */
    public function testValidatNegativEmail() {
        self::assertFalse(User::validateEmail("manuel.blechschmidtgmx.de"));
        #self::assertFalse(User::validateEmail("manuel%blechschmidt@gmx.de"));
        self::assertFalse(User::validateEmail("manuel.blechschmidt@gmxde"));
    }

    /**
    * Delete the Users file
    */
    public function tearDown() {
        unlink("users.txt");
    }
}
?>