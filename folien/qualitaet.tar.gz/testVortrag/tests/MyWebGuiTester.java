package tests;
import net.sourceforge.jwebunit.WebTestCase;
/**
 * Class which has some test cases for the GUI
 * @author Manuel Blechschmidt
 *
 */
public class MyWebGuiTester extends WebTestCase {

	/**
	 * Start the program
	 * @param args no args are used
	 */
	public static void main(String[] args) {
		junit.swingui.TestRunner.run(MyWebGuiTester.class);
	}

	/**
	 * Set the right variables
	 */
	protected void setUp() throws Exception {
		super.setUp();
		getTestContext().setBaseUrl("http://localhost/~manu/testVortrag/");
	}

    /**
     * Delete all users which were added
     */
	protected void tearDown() throws Exception {
		super.tearDown();
		clickLinkWithText("Alle l�schen");
	}
	
	/**
	 * Tests if add User works, if you fill in all fields 
	 *
	 */
	public void testAddUser() {
		beginAt("/");
		assertTitleEquals("WebInterface zum Testen");
		setFormElement("login", "harry");
		setFormElement("password", "btharme");
		setFormElement("vorname", "Harry");
		setFormElement("nachname", "Harter");
		setFormElement("email", "Harry@btuser.de");
		submit("ok");
		assertTableEquals("userTable", new String [][] {
				{"id","Login", "Passwort", "Vorname", "Nachname", "Email"},
				{"1", "harry", "btharme",  "Harry",   "Harter", "Harry@btuser.de"}
		});
	}
	
	
	/**
	 * Check if you get an error message if you not fill in all fields and the
	 * user isn't added
	 */
	public void testNotAllFilled() {
		beginAt("/");
		submit("ok");
		assertTextPresent("Bitte f�llen Sie alle Felder aus.");
		assertTableEquals("userTable", new String [][] {
				{"id","Login", "Passwort", "Vorname", "Nachname", "Email"}});
	}
	
	/**
	 * Test if an invalid Email is entered it the form stops
	 */
	public void testNegativeEmail() {
		beginAt("/");
		setFormElement("login", "harry");
		setFormElement("password", "btharme");
		setFormElement("vorname", "Harry");
		setFormElement("nachname", "Harter");
		setFormElement("email", "Harrybtuser.de");
		submit("ok");
		assertTextPresent("Bitte geben Sie eine valide Emailadresse ein.");
	}

}