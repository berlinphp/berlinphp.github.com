#!/usr/bin/perl

use WWW::Mechanize;
use Time::HiRes qw(time);
use strict;

my $agent = WWW::Mechanize->new();
my $baseUrl = "http://localhost/~manu/testVortrag/";
my %visitedUrls;

$| = 1; # flush immediatly

evaluate($baseUrl, "");

sub evaluate {
  my $pageName=shift;
  my $parentPage=shift;

  if(not defined $visitedUrls{$pageName}) {
      $visitedUrls{$pageName} = 1;
      print "Process: ".$pageName."\n";
      my $start = time;
      my $response = $agent->get($pageName);
      if($response->is_error) {
          print $pageName." produced an error: ".$response->code;
      }
      print "Needed: ".(time-$start)."\n\n";
      foreach my $link ($agent->links) {
         $link->url_abs !~ /^mailto/ && $link->url_abs =~ /$baseUrl/i && evaluate($link->url_abs, $pageName);
      }
  }
}

1;
