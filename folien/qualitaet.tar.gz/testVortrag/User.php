<?php
/**
* Class which manages all the user handling
* @author Manuel Blechschmidt
*/
class User {

    public $userid;
    public $login;
    public $password;
    public $firstname;
    public $lastname;
    public $email;

    private function __construct() {
    }
    
    /**
    * Load one user depending on the id
    */
    public static function loadUser($id) {
        if(!is_int($id)) {
            throw new Exception("The id of the User is not an integer");
        }
	if(file_exists("users.txt")) { // Check if file exists, if not say user not found
            $users = file("users.txt");
            foreach($users as $user) {
                $userData = explode("|", trim($user)); // Delete the last \n from the row
                if(((int) $userData[0])=== $id) {
                    $user = new User();
                    $user->id = (int)$userData[0];
                    $user->login = $userData[1];
                    $user->password = $userData[2];
                    $user->firstname = $userData[3];
                    $user->lastname = $userData[4];
                    $user->email = $userData[5];
                    return $user;
                }
            }
	}
        throw new Exception("User with id $id not found");
    }

    /**
    * Returns all users in an array
    */
    public static function loadAllUsers() {
        if(!file_exists("users.txt")) { return array(); } // If file not exists return an empty array
        $users = file("users.txt");
        $array = array();
        foreach($users as $user) {
            $userData = explode("|", trim($user));
	    $userData[0] = (int) $userData[0]; // convert the id
            array_push($array, $userData);
        }
        return $array;
    }

    /**
    * Adds an user to the database
    */
    public static function addUser($login, $password, $firstname, $lastname, $email) {
         if(!file_exists("users.txt")) { touch("users.txt"); }
         $newId = User::getHighestId()+1; // Get the highest id of the Users and increment it by one
         $fp = fopen("users.txt", "a");
         fputs($fp, "$newId|$login|$password|$firstname|$lastname|$email\n");
         fclose($fp);
	 return $newId;
    }

    /**
    * Returns the highest ID
    */
    private static function getHighestId() {
        $users = file("users.txt");
        $max = 0;
        foreach($users as $user) {
            $userData = explode("|", $user);
            if($userData[0]>$max) {
                $max = (int)$userData[0];
            }
        }
        return (int) $max;
    }

    /**
    * Delete all Users from the Datasource
    */
    public static function deleteAllUsers() {
        unlink("users.txt");
    }
    
    /**
    * Checks if an Email is correct
    * Email validation is very hard, because there are 
    * a lot of special things like special chars (�, �, �)
    * or server ips or subdomains or encodings.
    * I will just check the trivial things.
    */
    public static function validateEmail($email) {
        return (boolean)preg_match('/\w+@[\w.]+\.\w{2,8}$/', $email);
    }

}
?>