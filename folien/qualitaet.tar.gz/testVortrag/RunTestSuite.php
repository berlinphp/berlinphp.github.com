<?php
/**
 * Class which create the test suite for us
 * @author Manuel Blechschmidt
 */
include_once("PHPUnit2/Framework/TestSuite.php");
include_once("tests/Szenario1.php");
class RunTestSuite {
    public static function suite() {
        $suite = new PHPUnit2_Framework_TestSuite(new ReflectionClass('Szenario1'));
	return $suite;
    }
}
?>
